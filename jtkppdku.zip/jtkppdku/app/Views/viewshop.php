<?php

$nama = "Ardy";
$hobi = "Explore IT dan Network";

    echo "<h1>Hi, Saya $nama</h1>";
    echo "<h1>Hobi saya $hobi</h1>";

?>
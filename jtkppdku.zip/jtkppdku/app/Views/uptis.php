<!DOCTYPE html>
<html>
<head>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>JTK PPDKU</title>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>
  <?php 
foreach($css_files as $file): ?>
	<link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
</head>
<body>
	<div class="jumbotron">
      <h1 class="display-4 text-center">JTK PPDKU</h1>
      <p class="lead text-center">Senarai Nama JTK Mengikut Zon Kinta Utara</p>
      <hr class="my-4">
    </div>
  <h3>Senarai Nama Juruteknik Mengikut Zon Uptis </h3>
	<div>
		<a href='<?php echo site_url('uptis/zon_tasek')?>'>Tasek</a> |
		<a href='<?php echo site_url('uptis/zon_manjoi')?>'>Manjoi</a> |
		<a href='<?php echo site_url('uptis/products_management')?>'>Seri Ampang</a> |
		<a href='<?php echo site_url('uptis/offices_management')?>'>Lahat</a> | 
		<a href='<?php echo site_url('uptis/employees_management')?>'>Dato Panglima Kinta</a> |		 
    <a href='<?php echo site_url('uptis/jtkppd')?>'>JTK PPD/JPN</a> |	
	</div>
	<div style='height:20px;'></div>  
    <div style="padding: 10px">
		<?php echo $output; ?>
    </div>
    <?php foreach($js_files as $file): ?>
        <script src="<?php echo $file; ?>"></script>
    <?php endforeach; ?>
</body>
</html>

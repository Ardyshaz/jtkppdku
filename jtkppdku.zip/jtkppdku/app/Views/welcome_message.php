<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SisDirPPDKU</title>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>
  <body>
    <div class="jumbotron">
      <h1 class="display-4 text-center">JTK PPDKU</h1>
      <p class="lead text-center">Senarai Nama JTK Mengikut Zon Kinta Utara</p>
      <hr class="my-4">
    </div>
  <h1>Senarai Nama Juruteknik Mengikut Zon</h1>
  <ul class="nav nav-tabs">
    <li class="nav-item"> <a class="nav-link active" href="#">Tasek</a> </li>
    <li class="nav-item"> <a class="nav-link" href="#">Manjoi</a> </li>
    <li class="nav-item"> <a class="nav-link" href="#">Seri Ampang</a> </li>
    <li class="nav-item"> <a class="nav-link" href="#">Lahat</a> </li>
    <li class="nav-item"> <a class="nav-link" href="#">Dato Panglima Kinta</a> </li>
    <li class="nav-item"> <a class="nav-link" href="#">Sektor Perancangan</a> </li>
    <li class="nav-item"> <a class="nav-link" href="#">Sektor Psikologi Dan Kaunseling</a> </li>
  </ul>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
  </body>
</html>
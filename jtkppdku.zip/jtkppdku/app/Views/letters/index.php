<!-- app/Views/letters/index.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Letter Management System</title>
</head>
<body>
    <h1>List of Letters</h1>
    
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Content</th>
            <th>Created At</th>
            <th>Action</th>
        </tr>
        <?php foreach ($letters as $letter): ?>
            <tr>
                <td><?= $letter['id']; ?></td>
                <td><?= $letter['title']; ?></td>
                <td><?= $letter['content']; ?></td>
                <td><?= $letter['created_at']; ?></td>
                <td><a href="/letters/<?= $letter['id']; ?>">View</a></td>
            </tr>
        <?php endforeach; ?>
    </table>
    
</body>
</html>

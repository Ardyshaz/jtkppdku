<!-- app/Views/letters/show.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Letter</title>
</head>
<body>
    <h1>View Letter #<?= esc($letter['id']); ?></h1>
    
    <p><strong>Title:</strong> <?= esc($letter['title']); ?></p>
    <p><strong>Content:</strong> <?= esc($letter['content']); ?></p>
    <p><strong>Created At:</strong> <?= esc($letter['created_at']); ?></p>
    
</body>
</html>
